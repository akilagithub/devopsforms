#!/bin/sh



# Middleware

export ORACLE_BASE=/app/oracle
export ORACLE_HOME=$ORACLE_BASE/Middleware/Oracle_Home
export MW_HOME=$ORACLE_HOME
export WLS_HOME=$MW_HOME/wlserver
export WL_HOME=$WLS_HOME
export DOMAIN_BASE=$ORACLE_BASE/Middleware/Oracle_Home/user_projects/domains
export DOMAIN_HOME=$DOMAIN_BASE/forms_domain
export JAVA_HOME=/u01/oracle/jdk1.8.0_152
export PATH=$JAVA_HOME/bin:$PATH

# Forms compilation
export PATH=.:$MW_HOME/bin:$MW_HOME/forms/mesg:$PATH
export LD_LIBRARY_PATH=$ORACLE_HOME/jdk/jre/lib/amd64/native_threads:$ORACLE_HOME/oracle_common/jdk/jre/lib/amd64:$ORACLE_HOME/lib:$ORACLE_HOME/oracle_common/jdk/jre/lib/amd64/server
export FORMS_BUILDER_CLASSPATH=$MW_HOME/jlib/
export FORMS_PATH=/app/deploy/Summit:$ORACLE_HOME/forms
export TNS_ADMIN=$DOMAIN_HOME/config/fmwconfig
export TERM=vt220
export ORACLE_TERM=$TERM
export NLS_LANG=AMERICAN_AMERICA.AL32UTF8
export PATH=$PATH:$ORACLE_HOME/bin

for i in `ls *.fmb`
do
echo Compiling Form $i ....
$MW_HOME/bin/frmcmp_batch userid=summit/summit@PDBORCL module=$i module_type=form compile_all=yes window_state=minimize
done 

for i in `ls *.pll`
do
echo Compiling Form $i ...
$MW_HOME/bin/frmcmp_batch userid=summit/summit@PDBORCL module=$i module_type=library compile_all=yes window_state=minimize
done

for i in `ls *.mmb`
do
echo Compiling Form $i ....
$MW_HOME/bin/frmcmp_batch userid=summit/summit@PDBORCL module=$i module_type=menu compile_all=yes window_state=minimize

done




