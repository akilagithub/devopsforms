#!/bin/sh



# Middleware
export MW_HOME=/u01/data/domains/forms
export WLS_HOME=$MW_HOME/wlserver_10.3
export WL_HOME=$WLS_HOME
export ORACLE_HOME=$MW_HOME/Oracle_FRHome1
export ORACLE_INSTANCE=$MW_HOME/asinst_1
export FR_HOME=$ORACLE_HOME
export FR_INST=$ORACLE_INSTANCE
export DOMAIN_HOME=$MW_HOME/user_projects/domains/ClassicDomain
export JAVA_HOME=$MW_HOME/jrockit_160_29_D1.2.0-10

# Forms compilation
export PATH=.:$FR_HOME/bin:$FR_HOME/forms/mesg:$PATH
export LD_LIBRARY_PATH=$FR_HOME/jdk/jre/lib/amd64/native_threads:$FR_HOME/jdk/jre/lib/amd64:$FR_HOME/lib:$FR_HOME/jdk/jre/lib/amd64/server
export FORMS_BUILDER_CLASSPATH=$FR_HOME/jlib/
export FORMS_PATH=$ORACLE_HOME/forms
export TNS_ADMIN=$FR_INST/config
export TERM=vt220
export ORACLE_TERM=$TERM
export NLS_LANG=AMERICAN_AMERICA.AL32UTF8
export PATH=$PATH:$ORACLE_HOME/bin

echo Compiling Form $i ....
/u01/data/domains/forms/asinst_1/bin/frmcmp_batch.sh userid=summitSC/summitSC@PDB1 module=customers.fmt module_type=form parse=yes window_state=minimize



